//
//  ViewController.swift
//  ShowHideExercise
//
//  Created by Usuário Convidado on 26/04/24.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var lblName: UILabel!
   
    @IBOutlet weak var lblidade: UILabel!
    
    @IBOutlet weak var lblFaculdade: UILabel!
    
    @IBOutlet weak var lblGmail: UILabel!
    
    @IBOutlet weak var lblTelefone: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblName.text = "Meu nome é..."
        lblidade.text = "Minha Idade é..."
        lblFaculdade.text = "Estudo na..."
        lblGmail.text = "Email para contato"
        lblTelefone.text = "Telefone para contato"
        
    }

     
    @IBAction func ExibirBtn(_ sender: Any) {
        lblName.text = "Pedro S Sarli"
        lblidade.text = "20"
        lblFaculdade.text = "FIAP"
    }
         
    @IBAction func LimparBtn(_ sender: Any) {
        lblName.text = ""
        lblidade.text = ""
        lblFaculdade.text = ""
        lblGmail.text = ""
        lblTelefone.text = ""
    }
    
    @IBAction func ContatoBtn(_ sender: Any) {
        lblGmail.text = "ppsarli2004@gmail.com"
        lblTelefone.text = "11 98546-9070"
    }
    
}

